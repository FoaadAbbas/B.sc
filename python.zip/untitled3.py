# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 16:36:02 2022

@author: foaad
"""
c=0
ch=input("enter chr ")
if(len(ch)==1):
    s=input("enter sentence ")
    for char in s:
        c+=(char==ch)
    print(c)        
