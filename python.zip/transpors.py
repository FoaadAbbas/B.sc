# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 14:09:41 2022

@author: foaad
"""

matrix = [
    [0, 1, -2],
    [-1, 0, 3],
    [2, -3, 0]
]
def transpose(matrix):
    for x in matrix:
        y=x
        for x2 in y:
            if y.index(x2)!=matrix.index(x):
               matrix[len(m     
print(transpose(matrix))                
            