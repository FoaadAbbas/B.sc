# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 18:50:50 2022

@author: foaad
"""

def main():
    a,b,c=eval(input("Please insert triangle side:"))
    a=float(a)
    b=float(b)
    c=float(c)
    print("a=",a,",b=",b,",c=",c)
    print("Perimeter = ",f'{a+b+c:.3f}')
    p=float((a+b+c)/2)
    area=(p*(p-a)*(p-b)*(p-c))**(1/2)
    print("Area = ",f'{area:.3f}')
main()    