def findIndex(a,x):
    if x - int(x) < 0.5:
        x = int(x)
    else:
        x = int(x) + 1
    high = a[-1] 
    low  = a[0]
    mid  = a[(len(a)-1)//2]
    midPlace = (len(a)-1)//2
    if x > high:
        return -1
    elif x <= low:
        return 0
    elif x == high:
        return len(a)-1
    if x == mid : return int((len(a)-1)//2)
    if mid >= x : return mid
    if x > mid:
        return findIndex(a[midPlace:len(a)],x)
    if x < mid :
       return findIndex(a[0:mid+1],x)
print(findIndex([0,1,2,3,5],6))        
        
            