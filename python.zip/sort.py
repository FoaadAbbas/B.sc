def strCompress(string):
    indx=0
    compress_str=""
    str_len=len(string)
    while indx!=str_len:
        count=1
        while indx<str_len-1 and string[indx]==string[indx+1]:
                      count=count+1
                      indx=indx+1
        if count==1:
           compress_str+=str(string[indx])+"1"
        else:
           compress_str+=str(string[indx])+str(count)
        count=1
        indx=indx+1
    return compress_str

def strRestore(string):
    restore_str = ""
    contain_number = False
    for i in range(len(string)):#i assume that the string doesnt start with number!!!!
        if '9' >= string [i] >= '0':
            print(string[i])
            contain_number = True
            for i in range(int(string [i] )):
                restore_str += string[i-1]
                
    return restore_str if contain_number else string

def main():
    string="polina"
    stringd=strCompress(string)
    print(stringd)
    print(strRestore(string))
main()