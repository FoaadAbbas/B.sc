import random
def ran_4diffDigits():#func that returns random 4digit number with 4 diffrent digits
    while True:#while the random number we have,have at least two equal digits
        a = int (random.randint(1,9)) # first digit,and it cand be 0 cause if its 0 the number isnt 4digit
        b = int (random.randint(0,9)) # second digit
        c = int (random.randint(0,9)) #third digit
        d = int (random.randint(0,9))#fourth digit
        if a!=b and a!=c and a!=d and b!=c and b!=d and c!=d:#if the random number have 4 diffrent digs
            return (a*(10**3)+b*(10**2)+c*(10**1)+d*(10**0))#a is thousand,b is hundreds,c is tens,d is ones
        
def legalNumber(num):#func that checks if the num is legal(the 4 digits are diffrent)
    a = num%10#ones
    b = (num//10)%10#tens
    c = (num//100)%10#hundreds
    d = (num//1000)%10#thousands
    return not(a == b or a == c or a == d or b == c or b == d or c == d)#false if there is equal digits else true

def bulls(a,b):#func that returns the time of bulls(how many times the numbers in the same digit is equal)
    return (a%10 == b%10) + ((a//10)%10 == (b//10)%10) + ((a//100)%10 == (b//100)%10) + ((a//1000)%10 == (b//1000)%10)

def hits(a,b):#how many numbers are in common but not in the same digit(for instance aUnits=bThousands)
    aUnits = a%10
    aTens = (a//10)%10
    aHundred = (a//100)%10
    aThousands = (a//1000)%10 
    bUnits = b%10
    bTens = (b//10)%10
    bHundred = (b//100)%10
    bThousands = (b//1000)%10#we return the number of times the numbers are the same but not in the same digit
    return((aUnits in [bTens,bHundred,bThousands]) + (aTens in [bUnits,bHundred,bThousands]) + (aHundred in [bUnits,bTens,bThousands]) + (aThousands in [bUnits,bTens,bHundred]))        
      
def main():#more about the return,we do list with the other digits of the other number and cheeck if the digit in the number is in the list
    c = 0#count will default=2 because we need cpp cp at least
    cp = 0#how many times the previous player had to try in order to guees the number
    winner = ''#here will be the name of the player/players that gueesed the number with less ammount of tries
    print('*''%27s'%'COWS AND BULLS''%10s'%'*')#starting line
    print("*"*34)#starting lines   
    players = ['Noa','Boaz','David']#list that have the names of the 3 players     
    for i in range(3):#for every player from the three
        cpp = cp#in the end of the for we will have the c number of attempts for the first player
        cp = c#for the second player
        c = 1#for the third player
        print("player:            "+players[i])
        print("You have to guess an integer number that has 4 diffrent digits")
        a = 0#number that the player entered with default=0
        rNumber = ran_4diffDigits()#build random 4 digit number with 4 diffrent digits
        while bulls(a, rNumber)<4:#while the player didnt guees the number
            print('Attempt#%d.'%c)#the number of the attempt
            a = int(input("Please, enter your guees:"))#the guees of the player
            if legalNumber(a):#if the number has 4 diffrent digit
                c += 1#now the number of attempts is the current+1
                print('Hits: %d Bulls: %d'%(hits(a,rNumber),bulls(a,rNumber)))#print hits,bulls
            else:#if number have equal digits 
                print('*** %d is illegal. There should be 4 different digits in the number'%a)   
                print('*** No attempt counted. Try again. ')#the number is illegal so we dont count attemp
        print('%s *** guessed the number %d in %d attempts'%(players[i],rNumber,c-1))#because we started counting from 1 not 0 we substract that one  
    if c   == (min(c,cp,cpp)):#if first player have the lowest c(he gueesd with less attempts) 
                    winner += ' '+players[2]
    if cp  == (min(c,cp,cpp)):#not elif/else cause we may have draw(check second player)
                    winner += ' '+players[1]
    if cpp == (min(c,cp,cpp)):#not elif/else cause we may have draw(check third player)
                    winner += ' '+players[0]            
    print('*** Congratulations!! The winner is %s'%winner+'!!!')#the game ended(we are out of while),print the name of winner  
    print('***',"FINISH",'***')#end of code     
main()        
    
