# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 22:04:46 2022

@author: foaad
"""

def main():
    tav=''
    while tav!='Q' and tav!='q':
        print("\na or A average\n* multiply\nm minimum\nM maximum\n^ power\nQ or q quit")
        tav=(input("\nEnter char:"))
        if tav=='a' or tav=='A':#a,A=average
            a,b=eval(input("\nEnter 2 integers a,b:"))
            if int((a+b)/2)==(a+b)/2:#if the average is integer number
                print("\nThe average is the integer number:",int((a+b)/2))
            else:#if the avg isnot integer
                print("\nThe average is not integer number:",(a+b)/2)
        elif tav=='*':#multipiction,and int*int=int so we dont check
            a,b=eval(input("\nEnter 2 integers a,b:"))
            print(a,"multiply",b,"=",a*b)
        elif tav=='M':#max
            a,b=eval(input("\nEnter 2 integers a,b:"))
            print("\nThe maximum is:",a if a>b else b) #if a>b print max is a else print max is b
        elif tav=='m':#min
            a,b=eval(input("\nEnter 2 integers a,b:"))
            print("\nThe minimum is:",a if b>a else b)#if a<b print min is a else print min is b 
        elif tav=='^':#a to the power b
            a,b=eval(input("\nEnter 2 integers a,b:"))
            print()
            if(a == 0 and b == -1) or (a == 0 and b == 0): print('cant divide by zero')
            elif (a**b)==int(a**b):#if a to the power b is int number
                print(a,"to the power",b,"is the integer number",int(a**b))
            else:#if its rational
                print(a,"to the power",b,"is the rational number",a**b)
        elif tav=='q' or tav=='Q':#if we get q,Q we print finish and quite the loop
            print("Finish")
main()