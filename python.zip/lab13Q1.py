def has_same_digit(number):
    counter = [0]*10
    while (number > 0) :
        counter[(number%10)] += 1
        number //= 10
    for x in counter :
        if x > 1 : return False
    return True

def has_adjacent_digits(number):
    if 9 >= number >= 0:return True
    return abs((number%10) - (number//10%10)) != 1 and has_adjacent_digits(number//10)

def is_well_mixed(number):
    if len(str(number)) < 2:return False
    return has_same_digit(number) and has_adjacent_digits(number)

def main():
    x = "start"
    while x != 0:
        x = int(input("Enter positive integer(no less than 2 digits):"))
        if x >= 10:print(x,"is NOT a well-mixed number") if not(is_well_mixed(x)) else print(x,"is well-mixed number")
        elif x:print("The number must be positive and have at least 2 digits")
    print("Finish")
main()