# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 13:28:48 2022

@author: foaad
"""

def main():
    x=int(input("Please enter 4-digits integer: "))
    newx=(x%100)*100+(x//100)
    print("New number : ",newx)
    y=((x//1000)%2==0)+((x//100)%2==0)+((x//10)%2==0)+(x%2==0)
    print("The ammount of even digits in the number",x,"is",y)
main()    