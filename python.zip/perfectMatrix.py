def isPerfect(matrix):
    for i in matrix:
        for x in i:
            if i.count(x) > 1 or x > len(matrix) or x < 1: return False #check rows
    for i in matrix[0]:
        place = matrix[0].index(i)
        for j in range (1,len (matrix)):
            if i == matrix[j][place]: return False#check coulums
    return True#if both coulums and row are perfect return true
print(isPerfect([[1,2,3,4],
                 [4,3,2,1],
                 [1,3,4,2],
                 [2,4,1,3]]))        
 
def main():
    matrix_demantion=int(input("Enter matrix demension:"))
    matrix=[[0]*matrix_demantion]
    for i in range(matrix_demantion):    
        row = []
        for j in range(matrix_demantion):
            element = [eval(input(f"enter {matrix_demantion} elements in row {j} with commas:"))]
            row.append(element)
            matrix.append(row)
        
    print(matrix)
        
    
#main()