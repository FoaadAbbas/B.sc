def runners_times(n):
    times = []
    for i in range(n):
        times.append(float(input("%d.Enter time:"%(i+1)))) #add the times of the runners to list ogf times.
    return times

def my_avg(times, n):
    sum_t = 0
    for i in times:
        sum_t += i 
    avg_t = sum_t/n #caculate the average time of the times list
    avg_t = float('%.2f'%avg_t)
    return avg_t #return the average time.

def main():
    n = int(input("Enter number of runners:"))
    times = runners_times(n) #calls the function  to collect times runners * num of runners.
    belowAvg = 0
    for i in times:
        if i < my_avg(times, n): #if the time of the ï"runner is below the average, count + 1.
            belowAvg += 1
    print(f'Time average is {my_avg(times,n)}.\nThe number of runners, running below average time is {belowAvg}.')      
main()