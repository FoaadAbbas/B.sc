def printMat(mat):#func to print the matrix in good looking way
    for i in mat:#for every row in the matrix
        for x in i:#for every number in the row
            print(" "*2,x,end=" ")#print the number with spaces for good loking print
        print()#\n
        
def isPerfect(mat):
    RowCounter = []#list that shows us how many every number appeard in every row
    ColumCounter = []#list that shows us how mant every number appeard in every colum
    for i in range(len(mat)):
    #we bulid rowcounter in that way so we dont make every small list a pointer of other
    #so we can change without changing more than place in one time    
        RowCounter.append([0])#bulid list inside the big list,every list is for one row
        for x in range(len(mat)):
            RowCounter[i].append(0)#its all 0 in the start
    for i in range(len(mat)):
        #we bulid columCounter in that way so we dont make every small list a pointer of other
        #so we can change without changing more than place in one time    
        ColumCounter.append([0])#bulid list inside the big list,every list is for one colum
        for x in range(len(mat)):
            ColumCounter[i].append(0)#its all 0 in the start
    for row in range(len(mat)):#for every row
        for colum in range(len(mat)):#for every colum
            if mat[row][colum] > len(mat) or mat[row][colum] < 1 : return False
            #if there is number thats bigger than n or less than 1 return false
            else:
                RowCounter[row][mat[row][colum]] += 1#add 1 to the place of the number in the list of this row
                ColumCounter[colum][mat[row][colum]] += 1#same thing but for colums   
    for x in RowCounter :
        for y in x:
            if y > 1 : return False#if in one row,the same number showed more than 1 time false
    for x in ColumCounter:
        for y in x:
            if y > 1 : return False#if in one colum,the same number showed more than 1 time false
    return True        
def main():
    n = "start"#default ammount
    while n != 0:#while the matrix dimension isnt 0
        mat = []#we bulid the matrix from that start every time
        n = int(input("\nEnter the matrix dimension :"))#get the matrix dimension
        for i in range (n):#we bulid every row then from rows we build matrix
            row = eval(input(f"\nEnter {n} elements in row {i} with commas:"))#get row from user
            row = list(row)#change its type from tuple to list because we dont know how use tuple
            mat.append(row)#put the row inside the list
        printMat(mat)#print the mat in good looking way   
        if n != 0:  print("\nThe Matrix is perfect") if isPerfect(mat) else print("\nThe Matrix is not perfect")
    print("Finish")#if we get 0 we finished getting matrixes from the user
main()
   