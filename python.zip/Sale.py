# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 14:09:49 2022

@author: foaad
"""
def main():
    price=eval(input("Enter price, please: "))
    price=0.85*price
    print("Price after discount:",f'{price:.2f}')
main()
        


