import random
def dif_4digits(number):#return true if all the digits are diffrent,else return false
    one=number%10
    ten=(number//10)%10
    hundred=(number//100)%10
    thousand=(number//1000)%10
    return one!=ten and one!=hundred and one!=thousand and ten!=hundred and ten!=thousand and hundred!=thousand
def ran():
    flag=True
    while flag:#while the random number have equal digit make a new one
        randomNumber=random.randint(1000, 10000)
        if dif_4digits(randomNumber):
            return randomNumber#if the random number has 4 dif digits return it
def bulls(a,b):#we count how many times the digit is the same
    return (a%10==b%10)+((a//10)%10==(b//10)%10)+((a//100)%10==(b//100)%10)+((a//1000)%10==(b//1000)%10) 
def hits(a,b):#we count how many times digits are the same but in diffrent order,(ones=tens,tens=hundreds)
    onea=a%10
    tena=(a//10)%10
    hundreda=(a//100)%10
    thousanda=(a//1000)%10
    oneb=b%10
    tenb=(b//10)%10
    hundredb=(b//100)%10
    thousandb=(b//1000)%10
    return(onea==tenb)+(onea==hundredb)+(onea==thousandb)+(tena==oneb)+(tena==hundredb)+(tena==thousandb)+(hundreda==oneb)+(hundreda==tenb)+(hundreda==thousandb)+(thousanda==oneb)+(thousanda==tenb)+(thousanda==hundredb)
def main():
    print("******cows and bulls********")
    print("**************")
    players=['noa','boaz','david']
    attemptslist=[]
    attempts=1
    for i in range(3):
        ranx=ran()
        attemptslist.append(attempts)
        attempts=1
        print("player      ",players[i])
        print("you have to guess an integer number that has 4 diffirent digits:")
        x=0
        while(bulls(x,ranx)!=4):
            print("Attempt%d"%attempts)
            x=int(input("enter your gueess"))
            if dif_4digits(x):
                attempts+=1
                print("hits",hits(x,ranx),"bulls",bulls(x,ranx))
            else:
                print("illegal number")
        mintry=attemptslist[1]        
        winner=''
        for i in range(1,len(attemptslist)):
            if attemptslist[i]<mintry:
                mintry=attemptslist[i]
                winner+=players[i]
        print("the winner is: ",winner)     
        print("***finish")
main()                