# -*- coding: utf-8 -*-
"""
Created on Thu Oct 27 21:49:10 2022

@author: foaad 
"""

def true_id(id):
 if(id.isnumeric() is False):
     print("enter numbers only")
     return False
 i=8
 t=0
 while(len(id)<9):
        id=("0"+id)
 last=int(id[8])      
 for number in range(9) :
     if(i%2==0):
             t+=int(id[i])
             i-=1
     else:
            t+=((int(id[i])*2)%10)+((int(id[i])*2)//10)
            i-=1
 if(t%10==0):
    return True
 else:
     last=int(id[i])+(10-(t%10))
     while(last>=10):
         last=(last//10)+(last%10)
     print(last)
     return False
x=input("enter your id ")  
print(true_id(x))       


    
        
       
    
    
         
    