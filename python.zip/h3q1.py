def my_split(str,sep):
    newStr = []#str after spliting with sep
    indexes = []#list of places where the sep appears in str
    place = 0#index for chr in str
    while place+len(sep) < len(str):#if that isnt true we cant have sep
        if str[place:place+len(sep)] == sep: indexes.append(place)
        #if str from place to place = sep so add place to indexes
        place += 1#move to the next chr
    place = 0#back to default place so it easier to bulid newStr (back to the start of str)   
    for i in indexes:#for every place in str we have sep 
        newStr.append(str[place:i])#cut from the previous sep to the current
        place = i + len(sep)#move to the place afther the current sep
    if indexes != []:#if we have at least one sep
        newStr.append(str[indexes[-1]+len(sep):len(str)+1])#from the last sep to the last char 
    else:#if we dont have at least one sep
            newStr.append(str)#the newStr = str because no sep were found
    return newStr#return the str after spliting
#we have to add the part from last sep to last chr in the string after the for,because if we did 
#that inside the for we may get overflow
def main():
    str = "I wish you, as regular, health, wealth, great success"#our sentence
    sep =[" ",",","ea","abc"]#our seps
    print(str)#print original sentence
    for i in range(4):#for every sep in the output showen in the word file
        print("my_split with separator =",'"'+sep[i]+'"')#show with which sep we are working now
        print(my_split(str,sep[i]))#print sentence splited with current sep
main()
