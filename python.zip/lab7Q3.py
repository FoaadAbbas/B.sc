def printlst(lst):#print list elements
    for i in lst:
        print(i,end=' ')    
        
def mostRecent(number):
    if int(number) < 0:#we dont care if the number is negative 
        number =- number
    lst = []#.list of number digits
    maxAppear = 0#the max appear times
    mostRecent = []#most recent digit
    while int(number) > 0:#While there still digit to add
       lst.append(number%10)
       number//=10
    lst.sort()   #from small to big
    for i in lst:
        if i not in mostRecent:# if we didnt check that digit yet
            print(f'the digit {i} appears {lst.count(i)} times.')
        mostRecent.append(i)#we put the digit in mostRecent so we dont check the same number more than one time
        if lst.count(i) > maxAppear:
            maxAppear = lst.count(i)
    mostRecent = [] #we empty mostRecent
    if lst == []:
        maxAppear = len(str(number))
        mostRecent.append(0)
    for i in lst:# we dont have to use else/elif because if number=0 we wont enter that for
        if lst.count(i) == maxAppear and i not in mostRecent:
            mostRecent.append(i)#if the digit appears max times,add it to mostRecent
    print("The most frequent digit/s is/are: ",end='')
    printlst(mostRecent)
    print("\nIt occurs times ",maxAppear)
    
def main():
    number = 1#default num
    while int(number) != 0:
        number = (input("Enter integer:")) 
        number = int(number) if int(number) != 0 else number
        mostRecent(number)
main()    