# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 18:15:00 2022

@author: foaad
"""
def main():
 import math
 x=float(input("enter x "))
 y=float(x+math.sqrt((x**(1/3))+x**2))
 print(x,'+','sqrt',"(",x,'^(1/3)','+',x,'^2',')','=',f'{y:.2f}')
main()
