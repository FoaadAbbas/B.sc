def strCompress(string):
    count = 1#how many times the char appeard in sequence in string
    compressedString = ''#newstring after compressing
    for i in range(len(string)-1):#for every char but the last
        if string[i] == string[i+1]:#if the char = next char in string
            count += 1#add the length of sequence by 1
        else:#if they arent equal
            compressedString += string[i] + str(count)#add the current sequence
            count = 1#start counting from the start   
    compressedString += string[-1] + str(count)#because for doesnt give us last sequnce
    #because we dont have something to compare the last sequence with        
    return compressedString#return the newstr after compresiing

def strRestore(string):
    newStr = ""#newstr after restoring
    char = []#the characters we have
    appears = []#the numbers,which stands from length of sequnces
    for x in string :#for every thing in string
        if "z" >= x >= "a":#if its charchter add to char
            char.append(x)
        else:
            appears.append(int(x))#else add to appears
    place = 0#place of current char in string
    if len(appears) <=1 :#if we have 1 or 0 sequnces
        newStr = string
    else:#if we have more
        for x in char:#for evert charcter,add it appears[n]times
            newStr += str(x) * appears[place]#char*length of sequence of char
            place += 1#move to next char
    return newStr#return str after restoring

def main():
    string = input("Enter a section chain to compress:\n")#our sentence
    print("The compressed string is: ",strCompress(string))#compresed
    print("The restored string is: ",strRestore(string))#restored
main()    