def firstBigSame(lst,x):
    if lst[0] >= x : return 0
    if x > lst[-1] : return -1
    low , high= 0 , len(lst)-1
    while high >= low:
        mid = (high + low) // 2
        if mid == 0 or mid == len(lst) : return "error"
        if lst[mid] == x : return mid 
        if lst[mid] > x : high = mid - 1
        else : low = mid + 1 
    return mid
lst = [1,2,2,3,3,4]
print(firstBigSame(lst, 8))    





