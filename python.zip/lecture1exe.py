# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 11:01:31 2022

@author: foaad
"""
import math
def is_prime(x):
    for i in range (2,int(math.sqrt(x))):
        if x%i==0:
            return False
    return True    
def count_divisors(x):
    c=0
    for i in range(2,(x//2)+1):
        if (x%i)==0:
            c+=1
    return c
def main():
    x=int(input("Enter number: "))
    print(count_divisors(x))
    if count_divisors(x)%2==1:
        print(x,"is perfect square")
    else:
        print(x,"is not perfect square")
    print(is_prime(x))    
main()    