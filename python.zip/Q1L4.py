# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 13:18:06 2022

@author: foaad
"""
def main():
 w=int(input("Enter weight (in kg) :"))#Taking weight from the user and saving it in w
 h=int(input("\nEnter height (in cm) :"))#.......(but for height)
 BMI=float(w/((h/100)**2)) #calucating height in m,dividing the w in r**2 like the formula
 if(BMI<18.5): 
    print("Underweight")
 elif BMI<25.0:
    print("Normal weight")
 elif BMI<30.0:#less than 30 and bigger than 18.5
    print("Increased weight")    
 elif BMI<40.0:
    print("obese")
 else:
    print("very high obese")    
main()