def isletters(string):#func that checks if string is all leters or not
    if string == "" : return True#stopping condtion
    return ("z" >= string [0] >= "a" or "Z" >= string[0] >= "A") and isletters(string[1:])
#check every letter then call the func with the same string but without this letter
def main():
    string = input("Enter sentence ")#take string from user
    if string == "": print("Not all letters")#if not empty(so dont miss up with the stopping condtion)
    elif isletters(string): print("All letters")#call the func if string not empty
    else : print("Not all letters")#if func return false
main()    