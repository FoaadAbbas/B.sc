def length_of_string(s):
    if s == "" : return 0
    return 1+length_of_string(s[1:])#if there is more return 1+1+1+1 until you have one char

def main():
    text = "Experimental text to test recursive function."     
    print("Length of string:\n%s\n is %d."% (text,length_of_string(text)))
main()
