def is_onOff(n):#func that recives number and return list with fals,true(on,off)for every bulb in range n
    l = n*[False]#he turend the n bulbs off in the first time
    c = 1#counter with default=0
    for x in l:#the n times he moved accros the bulbs and turned on/off if i%c==0
        c += 1#add the counter to move to the next bulb
        for i in range(2,n+1):#for every bulb
            if i%(c) == 0:#if the place of bulb%the times he moved acrros=0
               l[i-1] = not l[i-1]#change the current on/off to the opposite
    return l #return the list after the changes

def main():#working alright but not efficent           
    c = 0#place of bulb,with default=0
    n = int(input("Enter number of bulbs: "))
    print("The bulbs that are turned off are:")
    for i in is_onOff(n):#we get the list with on/off from the func(according to number of bulbs)
        c += 1#place of bulb
        if i == False:#if the bulb is turned off
            print("[%d]"%c,end=" ")#print the number of the bulbs that are turned off one next to the other 
main()#the list in the place i will equal false if the bulb is off,else its true

#the code isnt efficent,from line 20 to lin 25 is the efficent way to solve this question
import math#we can see from the results that we print the numbers from 0 to square of n to the power 2
def is_onOffefficent(n):#efficent way
    for i in range(1,int(math.sqrt(n))+1):#from 1 to the square of number of bulbs
        print ('[%d]'%i**2,end=' ')#print number to the power 2
    return ''#in order to not get the word null in the last of our program

def main2():#efficent
    n = int(input("\nEnter number of bulbs: "))#number of bulbs
    print("The bulbs that are turned off are:")
    print(is_onOffefficent(n))#the bulbs that are off
main2()    

