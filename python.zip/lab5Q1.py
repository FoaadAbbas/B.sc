# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 12:54:57 2022

@author: foaad
"""
def  main():
    num=int(input("Enter Integer Number:"))
    abs=num
    c=0
    if num<0:
        abs=-num
        c+=1
    print("List of divisors of",num,":",end="")
    for i in range (1,(abs//2)+1):# from 1 to the absoulut value of num
        if num%i==0:#if i is divisor of num
            print(i,end=" ")#print i and dont jump to new row
            c+=1
    if num<0:# if num is negative print the positive num
        print(-num)  
    if num!=0 and num!=1:# if its not a specificily 0\1
        print("\nnumber of divisors is:",c)    
    elif num==0: # if 0 print that all the natural nubers can be divisors 
        print("\ninfinty-All natural numbers are divisors of 0")
    else :#if the number is 1
        print("1","\nnumber of divisors is:",1)
main()            