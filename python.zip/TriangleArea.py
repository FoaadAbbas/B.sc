# -*- coding: utf-8 -*-
"""
Created on Fri Nov  4 19:31:33 2022

@author: foaad
"""

def main():
    e=eval(input("enter edge of triangle "))
    h=eval(input("enter height of triangle "))
    s=(h*e)/2
    print("The area is ",f'{s:.3f}')
main()