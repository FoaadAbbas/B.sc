def isAlphabitic(string):
    if not string : return True
    return ("z" >= string[0] >= "a" or "Z" >= string[0] >= 'A') and isAlphabitic(string[1 :])

def main():
    string = input("Enter str ")
    print ("There is only english letters") if isAlphabitic(string) else print("not all chars are english letters")
main()    