# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 15:22:05 2022

@author: foaad
"""

a,b,c=eval(input("enter 3 numbers "))
if(a>0 and b>0 and c>0):
    if((a+b)<=c or (b+c)<=a or (c+a)<=b):
        print("thats not a traingle")
    else:
        if(a==b or a==c or b==c):
            if(a==b and a==c and b==c):
                print("equilateral traingle")
            else:
                print("issosceles traingle")
        else:
            print("normal traingle")
                               
        