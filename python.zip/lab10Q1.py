def mostRecent(string):
    string = string.lower()#change every uppercase to lowercase
    counts = [0]*26#list that shows how many times every char appeard count[0] appears of a
    chars = []#only a-z
    mostRecent = 'z'#start from the bigger chr
    for x in string:
        if "z" >= x >= "a":chars.append(x)#if its a-z append it
    for x in chars:
        counts[ord(x) - 97] += 1#ord(x) -ord(a) will give us the right place of the char in the lst
    maxApear = max(counts)#save the biggest number
    for x in range(len(counts)):
        if counts[x] == maxApear:#if the chr appeard as much as the maxApear
           if chr(x + 97) < mostRecent: mostRecent = chr(x + 97) #if its smaller than the current max
    return mostRecent if not(len(chars) == 0) else -1#if we have chars return the mostRecent else -1

def main():
    sentence = "default"#default value .....
    while sentence.lower() != "quit":#while not quit Quit qUit ......
        sentence = input("Enter a string, please: ")#take sentence from the user
        sentence = sentence.lower()#change every uppercase to lowercase
        if not(sentence.lower() == "quit"):#if the user didnt enter quit
            print("The most frequent letter is",mostRecent(sentence))#print the mostRecent
            print()#emptyLine    
    print("Thank you for exploring strings and complexity")#end of program        
main()    