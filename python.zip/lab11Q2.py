def recursive_has_prefix(str1,prefix):
    if prefix == "" : return True#stooping condtion
    if len(prefix) > len(str1)  or str1[0] != prefix[0] :
        #we cant have prefix longer than sentence or diffrent first letter
        return False 
    elif str1 != prefix:#while they arent at len(1)!!!!
           return recursive_has_prefix(str1[1:],prefix[1:])
    return True#if we never returend false        

def main():
 isPrefix = True
 while isPrefix:
     str1 = input("Please enter a string: ")
     pref = input("Please enter a prefix string: ")
     isPrefix = recursive_has_prefix(str1, pref)
     if isPrefix:
         print("The text has the prefix")
     else:
         print("No prefix")
 print("Finish")
main()