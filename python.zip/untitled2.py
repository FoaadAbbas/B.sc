def count_digits(number):
    if number <=  9 : return 1
    return 1 + count_digits(number//10)

def concatDig(lst,length):
    number = ""
    for x in lst:
        if x != 0 : number += "%.0f"%x
    return int(number)

def upToDown(lst,length):
    if length <= 1: return lst
    return [lst[-1]] + upToDown(lst[:-1], length - 1)
def int_to_str(num):
		string = ""
		while num:
					string = chr(num%10 + ord("0")) + string
					num //= 10
		return string			

def isIn(lst,number):
    number = "%.0f"%number
    for x in number :
        if int(x) not in lst : 
            return False
        else : lst = lst[lst.index(int(x)) : ]
    return True    

def is_abundant(number):
    Sum = 0
    for i in range(1 , number):
        if number % i == 0 : Sum += i 
    return Sum > number 

def is_abundant_matrix(matrix):
    for i in range(len(matrix)):
        if not is_abundant(matrix[i][i]) : return False
        if not is_abundant(matrix[i][len(matrix)] - i - 1) : return False 
    return True    

    