rcount = 0
tcount = 0
scount = 0
fcount = 0
maxCount = 0
maxLetter ='Z'
choice = input("Enter answers(R-radio, T-tv, S-social media,F-flyers, * to end)\n")
if choice == "*" : print("Survey results : No data")
else :
    while choice != "*":
           if choice != 'R' and choice != 'T' and choice != 'S' and choice != 'F':
               print("Illegal input:",choice)
           elif choice == "R":
                rcount += 1
                if rcount >= maxCount:
                    maxCount = rcount
                    if maxLetter < 'R' : maxLetter = 'R'
           elif choice == "T":
                tcount += 1
                if tcount >= maxCount:
                    maxCount = tcount
                    if maxLetter < 'T' : maxLetter = 'T'
           elif choice == "S":
                scount += 1
                if scount >= maxCount:
                    maxCount = scount
                    if maxLetter < 'S' : maxLetter = 'S'
           elif choice == "F":
                fcount += 1
                if fcount >= maxCount:
                    maxCount = fcount
                    if maxLetter < 'F': maxLetter = 'F'
           choice = input("")
print("Survey results :The best advertising strategy is: (%c)"%maxLetter)
