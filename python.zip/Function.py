# -*- coding: utf-8 -*-
"""
Created on Fri Nov  4 19:38:46 2022

@author: foaad
"""

def main():
    a=eval(input("enter a "))
    b=eval(input("enter b "))
    c=eval(input("enter c "))
    print("a*2+b**2+c= ",a,"*2","+",b,"**2","+",c,"=",a*2+b**2+c)
main()    