def how_many(string):
    if len(string)<1:
        return -1
    string.lower()
    nl=[0]*26
    newmax=0
    maxchar=""
    for i in range(len(string)):
        if string[i]>="a" and string[i]<="z":
           index=ord(string[i])-ord("a")
           nl[index]+=1
    for j in range(len(nl)) :
        if nl[j]>newmax:
            newmax=nl[j]
            ord_maxchar=ord("a")+j
            maxchar=chr(ord_maxchar)

    return maxchar if maxchar != "" else -1

def main():
    sentence = "start"
    while sentence != "quit":
        sentence = input("Enter a string, please: ")
        sentence = sentence.lower()
        if sentence != 'quit':print("\nThe most frequent letter is",how_many(sentence))
        print()
    print("Thank you for exploring srings and complexity")    
main()