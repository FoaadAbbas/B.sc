def goodPrint(lst): #func to print lst in goodloking way
    print("(",end='')
    print(lst[0],end="")
    for i in range(1,len(lst)):
        print(",",lst[i],end="")
    print(")",end="")    
    
def neigbors(mat,row,colum): #func to find the neignors of number in mat
    neigbors = [] #here will be all the neigbors of the number we entered
    for i in range(len(mat)): #for every row
        for j in range(len(mat[0])): #for every number in row
            if abs(i - row) + abs(j - colum) <= 2 and (i != row or j != colum) and not (i == row and abs(j - colum) >=2) and not (j == colum and abs(i - row) >=2):
                # if the distance is <= 2 and not all the distance coming from row or coming for colum , 
                # for instance we cant consider [0][0] and [0][2] as neigbors, also not [0][0] and [0][2]
                neigbors.append(mat[i][j]) #append it to the neigbors lst
    return neigbors #return lst with all neigbors

def check_mat(matr):
    count = 0 #coutn how many numbers are bigger than its neigbors
    for i in range(len(matr)):#for every row
        for j in range(len(matr[0])):#for every number in row
            if matr[i][j] > max(neigbors(matr,i,j)):#if the number is bigger than the bigger neigbor of him
                count += 1 #add the count by 1 
                print("%d. matr[%d][%d]=%d"%(count,i,j,matr[i][j]),end=" > ")
                goodPrint(neigbors(matr, i, j)) #print the neigbors
                print() #empty line because we are now checking new number
    return count #return the ammount of numbers that are bigger than thier neigbors

def main():
   mat = [[2,3,4,5,6],
          [6,5,7,4,3],
          [3,4,9,8,2],
          [5,4,8,7,6],
          [1,2,9,5,9]] #our mat
   print("\n\ncount =","6" if check_mat(mat) == 6 else "Oops somethign went wrong!" ) #if it doesnt return 6 there is something not ok 
main()   
             
                