def mostRecent(number):
    if number<0:
        number=-number
    lst=[]
    maxAppear=0
    mostRecent=[]
    while number>0:
       lst.append(number%10)
       number//=10
    lst.sort()   
    for i in lst:
        if i not in mostRecent:
            print(f'the digit {i} appears {lst.count(i)} times.')
        mostRecent.append(i)
        if lst.count(i)>maxAppear:
            maxAppear=lst.count(i)
    mostRecent=[]        
    for i in lst:
        if lst.count(i)==maxAppear and i not in mostRecent:
            mostRecent.append(i)
    print("The most frequent digit/s is/are: ",*mostRecent,"\nIt occurs times",maxAppear)    
def main():
    number=int(input("Enter integer:"))
    mostRecent(number)
main()    