
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 31 16:06:18 2022

@author: foaad
"""
x=(input("ammount of money: "))
if(x.isnumeric()):
 x=int(x)
 twohundres=(x//200)   
 hundreds=((x-twohundres*200)//100)
 fifties=((x-twohundres*200-hundreds*100)//50)
 twenties=((x-twohundres*200-hundreds*100-fifties*50)//20)
 tens=((x-twohundres*200-hundreds*100-fifties*50-twenties*20)//10)
 fives=((x-twohundres*200-hundreds*100-fifties*50-twenties*20-tens*10)//5)
 units=((x-twohundres*200-hundreds*100-fifties*50-twenties*20-tens*10-fives*5))
 print(twohundres,hundreds,fifties,twenties,tens,fives,units)
