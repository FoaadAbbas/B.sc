def number(num1,num):
    lst1=[]
    while num!=0:
        digit=num%10
        lst1.append(digit)
        num=num//10
    lst2=[]
    while num1!=0:
        digit=num1%10
        lst2.append(digit)
        num1=num1//10
    return(lst1)
    return(lst2)
def bulls(lst1,lst2):
    counter_bulls=0
    for i in range(len(lst1)):
            if lst1[i]==lst2[i]:
                counter_bulls+=1
    return(counter_bulls)
def hits(lst1,lst2):
    counter_hits=0
    for i in range(len(lst1)):
        for j in range(len(lst2)):
          if (lst1[j]==lst2[i]):
            counter_hits+=1
    return(counter_hits)
    return(lst1)
    return(lst2)

from random import randrange
def main():
    lst1=[]
    lst2=[]
    num=(randrange(1000,10000)) 
    attempt=0
    counter_Bulls=0
    counter_Hits=0
    num1=int(input("You have to guess an integer number that has 4 different digits")) 
    if num1>=1000 and num1<10000:
        while num!=0:
            digit1=num1%10
            digit2=num1//10%10
            digit3=num1//100%10
            digit4=num1//1000
            if digit1==digit2 or digit2==digit3 or digit3==digit4 or digit4==digit1:
             print("***",num," is illegal. There should be 4 different digits in the number*** No attempt counted. Try again") 
            else:
              while num1!=num:
               print(num1,num)   
               number(num1,num)
               hits(lst1,lst2)
               bulls(lst1,lst2)
               print("Hits",counter_Hits,"Bulls",counter_Bulls)
               if counter_Bulls!=4:
                  attempt+=1
    print(attempt)
main()

