def no_Duplicate(string):
    "function that takes string and returns it without duplicates "
    newStr = string[0]#string without duplicate will be saved here
    for i in range(1,len(string)):
        if string[i] != string[i-1]:
            newStr += string[i]
    return newStr            
    
def main():
    string = input("Enter a string,please: ")
    print("After removing all duplicates:",no_Duplicate(string))
main()     