def interaction(m,row,colum):
    sum1,sum2 = 0,0
    for i in range (len(m)):
        sum1 += m[i][colum]
    for j in range(len(m[0])):
        sum2 += m[row][j]
    return sum1 == sum2
m = [[0,7,9,2,3],
     [1,4,-1,3,0],
     [2,2,-3,-1,5],
     [0,0,2,0,-3]] 
a = [[4,3],[3, 2]]
b = [[-2, 3],[3, -4]]
def maxCross(m):
    cross = []
    for i in range(len(m)):
        for x in range(len(m[0])):
            if interaction(m,i,x) == True:
                cross.append(m[i][x])
    return max(cross)            
def multipyTwoMatrix(a,b):
    c = []
    for i in range (len(a)):
        cr = []
        for j in range(len(b[0])):
            t = 0
            for k in range(len(b)):
                t += a[i][k] * b[k][j]
            cr.append(t)
        c.append(cr)    
    return c
print(multipyTwoMatrix(a, b))    