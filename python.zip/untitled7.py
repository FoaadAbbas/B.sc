def is_perfect(matrix):#function that gets matrix and checks if its perfect
    for i in range(len(matrix)):#loop that goes over the matrix
        cnt_list=[0]*(len(matrix)+1)#creating list with the matrix length
        for j in range(len(matrix)):#goes over the rows
            if matrix[i][j]<1 and matrix[i][j]>len(matrix):#if the element in the cell is not betwen 1 and the matrix length return false
                return False
            else:
                cnt_list[matrix[i][j]]+=1#adding 1 to the cell that has the same index as the matrix element
        for j in cnt_list:#goes over the list if there is an element bugger that 1 return false
            if j>1:
                return False
    k=0#inializing 
    for i in range(len(matrix)):#loop that goes over the matrix
        cnt_list=[0]*(len(matrix)+1)#creating list with the matrix length
        for i in range(len(matrix)):#loop that goes over the colums
            cnt_list[matrix[i][k]]+=1#adding 1 to the cell that has the same index as the matrix element
        for j in cnt_list:#goes over the list if there is an element bugger that 1 return false
            if j>1:
                return False    
        k+=1#increment k so it goes over the next colum
    return True
def main():
    while 1: #loop that gets matrix as long as its dimension is not 0
         matrix=[]#creating matrix
         n=int(input("Enter the matrix dimension :"))#input dimension
         if n==0:break#if n equals 0 stop the loop
         #
         # Initialize an empty list to store the matrix values
         matrix = []
         
         # Loop through the number of rows to receive the values for each row
         for i in range(n):
           row = list(int, input("Enter {} elements in row {} with commas: ".format(n , i+1)).split())
           matrix.append(row)

         # Check if the matrix is perfect
         check_if_perfect = is_perfect(matrix)
         if check_if_perfect:
           print("The matrix is perfect!")
         else:
           print("The matrix is not perfect.")
    print("Finish")

main()