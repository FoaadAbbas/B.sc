def lst(number):
    lst = []
    while number:
        lst.append(number % 10)
        number//= 10
    return lst    
def is_tripleDigit(num):#func that takes num and returns true if num is tripleDigit number else false
    num = lst(num)#we converte the num to list so its easier to move from digit to digit
    for i in range(len(num)-1,1,-1):# for every digit in the num
        if int(num[i])%3 == int(num[i-1])%3 or int(num[i])%3 == int(num[i-2])%3 or int(num[i-1])%3 == int(num[i-2])%3:
            return False#if there is 2,3close numbers that have the same %3 the number isnt tripleDigit
    return True#if every 3 close digits have diffrent %3    

def is_selfCenterd(num):#func that takes num and returns true if its selfcenterd else it returns false
    num1 = lst(num)#we convert the num to list so its easier to move from digit to digit
    s = 0#default sum=0
    for i in range(len(num1)):#for evert digit in the number
        s += int(num1[i])**(len(num1))#add digit to the power len(num) to the sum
    return s == num# if the sum of every digit to the power len(Num)=num so num is selfcenterd    

def is_triangularNumber(num):#func that takes number and return true if its triangular else false
    s = 0#default sum=09
    i = 0#default natural number=0
    while s <= num:
        s += i#add the new natural number to the sum
        if s == num:
            return True#if sum of natural numbers=num num is triangular
        i += 1#to calucate next natural number
    return False#if we get sum>num but never num that means that num isnt triangular

def main():
    l = []#list that will contain the inputs we get from the user
    nElements = int(input("Enter the number of elements:"))#ammount of numbers we will recive 
    print("Enter",nElements,"numbers:")#we ask the user to start entering numbers
    for i in range(nElements):#for i in range ammount of numbers
        l.append(int(input()))#add the number we recived from the user to the list
    for x in l:
        if  x >= 100:#if the numbers is at least 3 digits
            print(x,"is 'triple' digits:","YES"if is_tripleDigit(x) else "NO")#if triple print yes else no
            print(x,"is 'self centered' digits:","YES"if is_selfCenterd(x) else "NO")#...centerd
            print(x,"is 'triangular number:","YES"if is_triangularNumber(x) else "NO")#.....triangluar
        else:#if the number have less than 3 digits
            print('number %d contains less than 3 digits' % x)
main()    
        