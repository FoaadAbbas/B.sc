def longestsequence(a):
    longestSequence = 1
    count = 1
    mostFrequent = 0
    for i in range(len(a) - 1):
        if a[i] == a[i + 1] :count += 1
        else :
            if count > longestSequence : 
                mostFrequent = i -  count + 1
                longestSequence = count
            count = 1
    return   longestSequence , mostFrequent     
print(longestsequence([0,0,0,0,1,1,1,1,1,1,1,1,1]))        