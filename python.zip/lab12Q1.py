def rstr2u(str):
    if str == "": return 0 #stopping condtion
    return (ord(str[-1]) - ord('0')) + 10 * (rstr2u(str[:-1]))
#return number in last digit and 10* number before it .... until empty
#i know the number by using to ord of 0
def isnumric(string):#func that return true if number , else false
    if string == "" : return False#empty string isnt number
    for char in string :#for every char in string
        if not  ("9" >= char >= "0") : return False#if not number
    return True#if all are numbers

def main():
    string = input("Enter string you want to convert to number ")
    if isnumric(string) :#if number
        print ("The string is '%s'"%string)#the string
        print("The number is",rstr2u(string))#the number in string
    else:#if not number
        print("Wrong input !@!#!@#!@#")
main()        