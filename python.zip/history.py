runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec  7 16:00:56 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec  7 21:03:15 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec  7 22:43:47 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 07:40:21 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 08:15:45 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 10:18:58 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 12:39:43 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 17:07:52 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec  8 22:08:09 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Dec  9 17:30:54 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW1_FoaadAbbas_213819584_WadeaNahhas_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW1_FoaadAbbas_213819584_WadeaNahhas_213553522')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 10 00:18:13 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/robaa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/robaa.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 10 09:36:42 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 10 09:45:50 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 10 17:53:41 2022)---
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/nahla.py')
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 11 09:56:37 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 11 11:40:57 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 11 12:21:19 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 11 23:22:37 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 10:29:39 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 10:35:06 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab7Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 11:57:37 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 13:04:23 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 13:26:57 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')
copyright
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 13:46:49 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled4.py')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 14:50:32 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/trgol1212.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/trgol1212.py')
runfile('C:/Users/foaad/.spyder-py3/trgol1212.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/trgol1212.py')
4*3
4+2
1230*1230
runcell(0, 'C:/Users/foaad/.spyder-py3/trgol1212.py')
runfile('C:/Users/foaad/.spyder-py3/trgol1212.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 19:20:14 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 20:20:07 2022)---
runfile('C:/Users/foaad/.spyder-py3/q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 12 21:00:33 2022)---
runfile('C:/Users/foaad/AppData/Local/Temp/Rar$DRa4888.14145/HW2_213819584_213553522/q2.py', wdir='C:/Users/foaad/AppData/Local/Temp/Rar$DRa4888.14145/HW2_213819584_213553522')

## ---(Mon Dec 12 21:01:34 2022)---
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
11
runfile('C:/Users/foaad/.spyder-py3/nahla.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/saed.py')
runfile('C:/Users/foaad/.spyder-py3/saed.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 13 08:50:19 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Program Files/Spyder/pkgs/spyder_kernels/py3compat.py', wdir='C:/Program Files/Spyder/pkgs/spyder_kernels')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 13 12:49:50 2022)---
runfile('C:/Users/foaad/.spyder-py3/h2q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 13 17:59:25 2022)---
b = (num//10)%10#tens
c = (num//100)%10#hundreds

## ---(Tue Dec 13 18:24:13 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec 14 13:00:30 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled4.py')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
asd
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec 15 09:21:44 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 18 23:03:19 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab8Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab8Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 19 15:15:42 2022)---
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled4.py')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled4.py')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 19 17:21:39 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 19 18:49:33 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled4.py')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled4.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 20 09:35:58 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled5.py')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled5.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Dec 23 17:19:40 2022)---
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
print(mat)
from main 
from main import(mat)
main(mat)
print(main(mat))
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runcell(0, 'C:/Users/foaad/Downloads/lab09Q2.py')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
debugfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runcell(0, 'C:/Users/foaad/Downloads/lab09Q2.py')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q2.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/Downloads/lab09Q1.py', wdir='C:/Users/foaad/Downloads')
runfile('C:/Users/foaad/.spyder-py3/lab09Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab09Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Dec 23 22:43:31 2022)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/h3q1.py')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled6.py')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 24 12:43:39 2022)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled6.py')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled6.py')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 24 16:02:07 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 25 09:37:14 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled7.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/h3q3.py')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Dec 25 23:11:00 2022)---
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Program Files/Spyder/pkgs/spyder_kernels/py3compat.py', wdir='C:/Program Files/Spyder/pkgs/spyder_kernels')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/salwa.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 26 14:46:06 2022)---
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 26 15:29:26 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled8.py')
runfile('C:/Users/foaad/.spyder-py3/untitled8.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Dec 26 19:51:14 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled8.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 27 09:55:12 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled8.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Dec 27 15:20:11 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled6.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec 28 12:00:10 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec 28 12:59:21 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Dec 28 21:13:38 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab10Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec 29 11:27:03 2022)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec 29 12:22:40 2022)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Dec 29 16:55:56 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Dec 30 14:16:12 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 31 12:32:36 2022)---
runfile('C:/Users/foaad/.spyder-py3/lab10Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab10Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
"ttttttttttt" == "ttttttttttt"
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sat Dec 31 22:30:54 2022)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan  1 09:48:49 2023)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
kkkpppppaaaaaaabttttttttttt == kkkpppppaaaaaaabttttttttttt
"kkkpppppaaaaaaabttttttttttt" == "kkkpppppaaaaaaabttttttttttt"
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan  1 18:48:37 2023)---
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan  2 10:25:49 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan  2 17:26:10 2023)---
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/h3q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan  2 19:14:09 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Jan  3 15:25:47 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')

## ---(Tue Jan  3 19:59:01 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')

## ---(Wed Jan  4 12:56:15 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled10.py')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled10.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan  5 14:24:50 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan  5 14:49:43 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan  5 15:52:20 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan  8 09:36:05 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan  9 15:13:10 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Jan 10 08:52:29 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Jan 10 09:52:07 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Jan 10 11:11:00 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Jan 11 12:59:26 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab11Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled11.py')
runfile('C:/Users/foaad/.spyder-py3/untitled11.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled11.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled11.py')
runfile('C:/Users/foaad/.spyder-py3/untitled11.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled11.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled11.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled12.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan 12 13:03:22 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan 12 13:26:18 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab12Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12Q2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/lab12q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Jan 13 12:13:34 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runcell(0, 'C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled9.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Fri Jan 13 20:51:56 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sat Jan 14 00:48:59 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sat Jan 14 12:09:33 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runcell(0, 'C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sat Jan 14 15:39:00 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW3_213819584_213553522')

## ---(Sat Jan 14 15:46:59 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sun Jan 15 07:55:42 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sun Jan 15 08:18:59 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Sun Jan 15 17:15:25 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Mon Jan 16 12:52:25 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/.spyder-py3/lab3Q1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Mon Jan 16 14:43:42 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Mon Jan 16 19:52:01 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q2.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q1.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Tue Jan 17 10:46:20 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Tue Jan 17 15:18:42 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/untitled0.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Jan 18 14:12:33 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab13Q2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Jan 18 21:01:33 2023)---
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')
runfile('C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/OneDrive/Desktop/לימודים/מלמ/תרגילי בית/HW4_213819584_213553522')

## ---(Thu Jan 19 14:12:46 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan 19 14:35:13 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan 19 15:20:01 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jan 19 21:24:43 2023)---
runfile('C:/Users/foaad/AppData/Local/Temp/Rar$DRa11380.24513/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/AppData/Local/Temp/Rar$DRa11380.24513/HW4_213819584_213553522')
runfile('C:/Users/foaad/AppData/Local/Temp/Rar$DRa11380.24513/HW4_213819584_213553522/q3.py', wdir='C:/Users/foaad/AppData/Local/Temp/Rar$DRa11380.24513/HW4_213819584_213553522')

## ---(Sun Jan 22 10:13:38 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan 23 15:03:01 2023)---
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled1.py')
runfile('C:/Users/foaad/.spyder-py3/untitled1.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Jan 23 15:24:21 2023)---
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon Feb  6 16:39:38 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')

## ---(Mon Feb 20 15:33:33 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Feb 22 22:27:04 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Feb 22 23:22:51 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Feb 26 13:35:37 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Feb 26 21:09:08 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled2.py')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled2.py')
runfile('C:/Users/foaad/.spyder-py3/untitled2.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled9.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Mar 26 08:19:29 2023)---
runfile('C:/Users/foaad/.spyder-py3/lab6Q3.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Apr 27 08:04:30 2023)---
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Apr 27 08:21:53 2023)---
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon May 15 16:15:34 2023)---
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Mon May 15 21:51:16 2023)---
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Jun 21 22:12:10 2023)---
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/fibo.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jun 22 09:01:12 2023)---
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/barah.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Thu Jun 22 19:43:54 2023)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/program files/spyder/pkgs/ipykernel/kernelbase.py', wdir='C:/program files/spyder/pkgs/ipykernel')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Sep  3 12:32:26 2023)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Jan 19 00:21:40 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan 21 09:19:24 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan 21 09:20:26 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan 21 12:16:27 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Jan 21 13:08:56 2024)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Fri Jan 26 00:00:44 2024)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
x = 0
t = 0
while(True):
t = 3**x + 9*8**x
if(t % 5 != 0):
print(t)
break
runcell(0, 'C:/Users/foaad/.spyder-py3/untitled0.py')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue Jan 30 16:29:07 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Wed Feb  7 23:07:38 2024)---
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Mar 31 01:43:25 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Mar 31 11:07:28 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Sun Mar 31 11:12:34 2024)---
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
runfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')
debugfile('C:/Users/foaad/.spyder-py3/untitled0.py', wdir='C:/Users/foaad/.spyder-py3')

## ---(Tue May 21 17:51:16 2024)---
runfile('C:/Users/foaad/.spyder-py3/worod.py', wdir='C:/Users/foaad/.spyder-py3')