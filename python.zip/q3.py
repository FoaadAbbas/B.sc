def in_place(i,n):#function that returns the number in certain digit
    return (n%(10**(i)))//(10**(i-1))
def main():
    a,b=eval(input("Enter two octal numbers:\n"))
    flag=True#boolean that tells is if a,b is octal
    i=1#index that tells us in which rank of the number we are
    sum=a#sum,we start from number and add to that sum the other number
    dynamicb=b#we do our work at that varrible so we can get the original b
    dynamica=a#we do our work at that varrible so we can get the original a
    while flag and (dynamicb!=0 or dynamica!=0):
        if in_place(i,a)>=8 or in_place(i,a)<0:#if a contains digit that is bigger than 8 or less than 0
            print("Illegal input ")
            flag=False
        if in_place(i,b)>=8 or in_place(i,b)<0:#if b contains digit bigger than 8 or less than 0
            print("Illegal input ")
            flag=False
        elif ((in_place(i, sum)+in_place(i, b)))<8:#if the sum of digits in place i in two number a,b is <8 
            sum+=(in_place(i, b))*(10**(i-1))#we add the value of b in that digit(a we already added)
        else:
            segma=((in_place(i,b)+in_place(i,a))-8)#when you add two digits and get sum bigger than 8 you add the two digits -8 to the current digit
            sum+=10**(i)#we add 1 to the next digit
            sum+=segma*(10**(i-1))
            sum-=in_place(i,a)*(10**(i-1))#because we started from a we have to substract the a in that digit if we get sum of digits>8
        i+=1#we move to the next digit
        dynamicb=dynamicb//10#delete ones
        dynamica=dynamica//10#delete ones
    if flag:#if a,b are octal        
        print("The sum is the octal number:",sum)        
main()            