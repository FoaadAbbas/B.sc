def input_list(n):
    lst=[]#lst of numbers
    for i in range(n):
        lst.append(int(input("%d.Enter integer:"%(i+1))))#add n numbers to the list
    return lst#lst with user numbers    
def create_new_list(a,x):
    """
    Parameters
    ----------
    a : List of numbers.
    x : number.

    Returns
    -------
    sorted list
        the list that fun return is sorted [<x and then >=x].

    """
    new_list=[]
    for i in a:
        if i<x:
           new_list.append(i)
    for i in a:
        if i>=x:
            new_list.append(i)
    return new_list
def main():
    a=input_list(7)
    x=int(input("\nEnter x:"))
    print("Original list:  ",a)
    print("New list:  ",create_new_list(a, x))
main()    