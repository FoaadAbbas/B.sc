def commonLetters(string):
    lettersCount = [0] * 26
    wordsCount = 0
    