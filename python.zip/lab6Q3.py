import math
g=9.81
def deg2rad(a):#function that takes angle in degrees and return it in radians
    return (a/180)*math.pi #degree/180*pi => radians
def horizontal(v,a,t):#function that calucate the horizontal space obj moved
    return (v*math.cos(deg2rad(a)))*t#vx*t,v*cos a *t
def height(v,a,t):#.......vertical space obj moved
    return v*math.sin(deg2rad(a))*t-(g*t**2)/2#vy*t,v*sin(a)*t-(gravity impact)
def main():
    v,a=0,0#default v a is 0
    while 100>=v>=0 and 90>=a>=0:# while the user gived us a valid speed and angle
        v=float(input("Enter speed 0-100(m/s):"))
        if 100>=v>=0:#while speed is valid
            a=float(input("Enter angle 0-90(degrees):"))
            if 90>=a>=0:#while speed,angle is valid because its in the big if
                 t=0.1#default time
                 while height(v,a,t)>=0:#while v,a is valid and height>=0
                     print("Time:"'%.1f'%t+"....""S="'%.2f'%horizontal(v, a, t),"H:"'%.2f'%height(v, a, t))
                     t+=0.1#add to the t in order to calucate new s,t
                 print("Time:"'%.1f'%t+"....""S="'%.2f'%horizontal(v, a, t),"H:"'%.2f'%height(v, a, t))  
                 print("Fallen!")#when we are out of the while the object fallen
            else:#if speed isnt valid
                print("Finish")
        else:#if angle isnt valid
            print("Finish")
main()#in the print we used f to take only 1,2 numbers after the decimal dot 