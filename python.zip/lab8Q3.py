def divideSentence(sentence):#function that divide the sentece to words
    firstCh = len(sentence)#here will be the place of the first char
    for i in range(len(sentence)):# for every char in the sentence 
        if sentence[i] != " " and sentence[i] != "\t":#if its not tab or empty chr
            if i < firstCh:#find the first letter
                firstCh = i
            print(sentence[i],end='')#print the letters untill you face tab or empty chr
        elif i+1<len(sentence):#if the sentence isnt only tabs or empty chars we will enter
            if sentence[i+1] != " " and sentence[i+1] != "\t":
                if i > firstCh :print() #when you face empty char or tab,if its not in the start print empty line

def main():
    sentence = input("Enter a string,please:")
    while sentence !="" and sentence !="\t":#while the user in entering valid strings
        divideSentence(sentence)
        sentence = input("\nEnter a string,please:")#take new string from the user
    print("Finish")#we finished taking strings    
main()        
        