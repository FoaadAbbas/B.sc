def TriangleReversed(letter,num):
    print("*** Triangle ***")#start line
    for i in range(int(num),0,-1):#number of lines
        for j in range(i,0,-1):#how many times the letter will appear in the line 
            print(letter,end=' ') 
        print()    
def main():
    letter=input("Enter a letter:")#reciving letter
    num=int(input("\nEnter an integer:"))#ammount of lines
    TriangleReversed(letter, num)
main()    