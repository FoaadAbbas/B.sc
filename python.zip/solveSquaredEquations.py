# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 15:54:04 2022

@author: foaad
"""
import math
a,b,c=eval(input("enter abc "))
if((b**2)-(4*a*c)<0):
    print("there is no soultions")
elif((b**2)-(4*a*c)==0):
    print("one soultion: ",-b/(2*a))   
else:
    print("two soultions: ",(-b+math.sqrt(b**2-4*a*c))/(2*a),(-b-math.sqrt(b**2-4*a*c))/(2*a)) 
