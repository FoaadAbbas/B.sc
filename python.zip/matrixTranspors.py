matrix = [
    [0, 1, -2],
    [-1, 0, 3],
    [2, -3, 0]
]

'''
1 2 9
2 4 0
3 1 1
'''

def transpose(matrix):
    transpose = []
    cols = len(matrix[0])
    for i in range(cols):
        new_row = []
        for row in matrix:
            new_row.append(row[i])
            
        transpose.append(new_row)
    return transpose

def print_matrix(matrix: list):
    for row in matrix:
        print('|', sep=' ', end=' ')
        for x in row:
            print(x, sep=' ', end=' ')
        
        print('|')

print('Matrix:')
print_matrix(matrix)

print('Transposed:')
print_matrix(transpose(matrix))