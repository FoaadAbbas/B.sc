def is_palindrom(list1):
    if len(list1) <= 1 : return True#empty list or list with one number
    if list1[0] == list1[-1] :#while we dont have diffrent a[0] a[-1]
        return is_palindrom(list1[1:-1])#while true call the func again
    else: return False#if we find diffrent a[0] and a[-1]

def main():
    yn = "default"
    while yn != "n":
        list1 = input("Enter numbers sepreated by commas:\n")
        if len(list1) > 1 : list1 = list(eval(list1))
        else : list1 = [list1]
        print("The list is a palindrom") if is_palindrom(list1) else print("The array is not a palindrom")
        yn = input("\nTry again(y/n)?")
        print() if yn != 'n' else ""
    print("Finish.")
main()    