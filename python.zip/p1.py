# -*- coding: utf-8 -*-
"""
Created on Tue Nov 22 19:02:21 2022

@author: foaad
"""

def main():
    number=int(input("Enter a positive integer (-1 for end): "))
    length = 1
    previous = 0
    max_length = 0
    max_value = number
    while number!=-1:
        previous = number
        number=int(input("Enter a positive integer (-1 for end): "))
        if previous==number:
            length += 1
        else:
            if max_length < length:
                max_length = length
                max_value = previous
            elif max_length == length:
                if max_value < previous:
                    max_value = previous
            length = 1
    print(f"the maximum sequence is: {max_length}, the max value is:{max_value}")
main()