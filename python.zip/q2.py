def is_off(n):
    c = 2#the times he scanned the bulbs
    bulbs = [False] * n
    while c <= n:#while the times he scanned is smaller than number of bulbs
        for x in range (1,n+1):#for every bulb
            if not x%c:#if place of bulb % times he scanned == 0
                bulbs[x-1] = not bulbs[x-1]#switch the bulb off or on
        c += 1#now he finished one path of scanning
    place = 1 #the place of bulb   
    for bulb in bulbs:
        if not(bulb):#if the bulb is off
            print('[%d]'%place,end=' ')
        place += 1    
def main():
    print("The bulbs that are turned off are:")
    is_off(100)
main()    