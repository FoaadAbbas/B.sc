def minShiftedList(arr , arrlen):
    minValue = arr[0]
    left , right = 0 ,(arrlen - 1)
    while left <= right:
        if (arr[left] <= arr[right]):
            return min(minValue , arr[left])
        mid = (left + right) //2
        minValue = min(minValue , arr[mid])
        if(arr[mid] >= arr[left]):
            left = mid + 1
        else:
            right = mid - 1
def main():
    list = [9,7,5,3,2]
    print(minShiftedList(list , 5))
main()