def findLargest(sentence):
    """
    

    Parameters
    ----------
    sentence:str 
        

    Returns
    -------
    index of the largest char
        DESCRIPTION.
        the function find the largesrt char and returns the index of it
    """
    sentence = sentence.lower()
    Large = sentence[0]
    for char in sentence:
        if 'z' >= char >= 'a':
            if char > Large:
                Large = char
    return sentence.index(Large)

#function that takes sentence and returns the index of the smallest char 
def findSmallest(sentence):
    sentence = sentence.lower()
    Small = sentence[0]
    for char in sentence:
        if 'z' >= char >= 'a':
            if char < Small:
                Small = char#
    return sentence.index(Small)


def main():
    sentence = input("Enter your sentence: ")
    print("Largest and smallest alphabet is : ",end="")
    print(sentence[findLargest(sentence)],end=" ") if 'z'>= sentence[findLargest(sentence)] >= 'a' else print("no alphabet chars were found")
    print(sentence[findSmallest(sentence)]) if 'z'>= sentence[findSmallest(sentence)] >= 'a' else "no alphabet chars were found"
main()    