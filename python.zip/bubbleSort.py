def buble_1(lst):
    if len(lst) < 2 or lst[0] < lst[1]: return lst
    else: 
        lst [0] , lst[1] = lst[1] , lst[0] 
    return  [lst[0]] + buble_1(lst [1 : ]) 

print(buble_1([7,6,8,9,14,17]))