# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 20:40:25 2022

@author: n0502
"""

import random    
def equal_digits(lst):
    for i in range(len(lst) - 1):
        for j in range(i + 1, len(lst)):
            if lst[i] == lst[j]:
                return False
    return True
def bulls_counter(lst,num):
    bulls=0
    for i in range(len(lst)-1,-1,-1):
        if lst[i]==num%10:
            bulls+=1
        num=num//10  
    return bulls            
def hits_counter(lst,num):
    hits=0 
    lst_num=[]
    covered_lst=[]
    for i in range(4):
        lst_num.append(num%10)
        num//=10
    for i in range(len(lst_num)-1,-1,-1):
        covered_lst.append(lst_num[i])
    for i in range(len(lst)):
            if lst[0]!=covered_lst[0]:
                if covered_lst[0]==lst[i]:
                    hits+=1
    for i in range(len(lst)):
            if lst[1]!=covered_lst[1]:
                if covered_lst[1]==lst[i]:
                    hits+=1
    for i in range(len(lst)):
        if lst[2]!=covered_lst[2]:
            if covered_lst[2]==lst[i]:
                hits+=1
    for i in range(len(lst)):
        if lst[3]!=covered_lst[3]:
            if covered_lst[3]==lst[i]:
                hits+=1                    
    return hits
def main():
    lst=[0]*4
    while (equal_digits(lst)!=True):
        for i in range(len(lst)-1):
            lst[i+1]=random.randrange(0,9)
        lst[0]=random.randrange(1,9)
    print(lst[3]+lst[2]*10+lst[1]*100+lst[0]*1000)    
    num=0
    names=["noa","boaz","david"]
    counts= []
    count_attempts=0
    for i in range(3):
        counts.append(count_attempts)
        count_attempts=1
        num=0
        while (equal_digits(lst)!=True):
            for i in range(len(lst)-1):
                lst[i+1]=random.randrange(0,9)
                lst[0]=random.randrange(1,9)
        while(bulls_counter(lst,num)!=4):
                print("player    ",names[i])
                print("you have to guess an integer number that has 4 diffirent digits:")
                print("attempt #",count_attempts)
                num=int(input("please enter your guess:"))
                print("hits:",hits_counter(lst,num),"bulls:",bulls_counter(lst,num))
                count_attempts+=1
                a=lst[3]+lst[2]*10+lst[1]*100+lst[0]*1000
                print(names[i],"***","gusess the number",a,"in",count_attempts-1,"attempts") 
        mintry=counts[0]
        for i in range(4):
            if counts[i]!=0 and counts[i]<mintry:
                mintry=counts[i]
                winner=names[i]
        print("***The winner is: ",winner)
        print("***Finish!") 
main()
