def is_perfect(matrix):#function that gets matrix and checks if its perfect
    for i in range(len(matrix)):#loop that goes over the matrix
        cnt_list=[]#for every row,here will be appear how many times appeard(every list is row every place in list is number!)
        columcnt_list=[]#same things for colum,we bulid the lists at that way so they doesnt point one to other!
        for i in range(len(matrix)):#put lists inside counting list,in the len of mat
            cnt_list.append([0])
        for x in cnt_list:
            for i in range(len(matrix)):
                x.append(0)#the len of every list in the new list = len(matrix)
        for i in range(len(matrix)):
            columcnt_list.append([0])
        for x in columcnt_list:
            for i in range(len(matrix)):
                x.append(0)
        for i in range(len(matrix)):       
            for j in range(len(matrix)):#goes over the rows
                if matrix[i][j]<1 or matrix[i][j]>len(matrix):#if the element in the cell is not betwen 1 and the matrix length return false
                    return False
                else:
                    cnt_list[i][matrix[i][j]] += 1#adding 1 to the cell that has the same index as the matrix element
                    columcnt_list[j][matrix[i][j]] += 1     
        for j in cnt_list:#goes over the list if there is an element bugger that 1 return false
            for number in j:
                if number > 1:
                    return False
        for x in columcnt_list:
            for number in x:
                if number > 1:
                    return False
    return True

def main():
    while 1: #loop that gets matrix as long as its dimension is not 0
         matrix = []#creating matrix
         n = int(input("Enter the matrix dimension :"))#input dimension
         if n == 0:break#if n equals 0 stop the loop
         #
         # Initialize an empty list to store the matrix values
         matrix = []
         
         # Loop through the number of rows to receive the values for each row
         for i in range(n):
           row = list(eval(input("\nEnter "+str(n)+" elements in row "+str(i)+" with commas: ")))
           matrix.append(row)
         for row in matrix:
             for number in row:
                 print(" "*2,number,end="")
             print()    
         # Check if the matrix is perfect
         check_if_perfect = is_perfect(matrix)
         if check_if_perfect:
           print("The matrix is perfect!")
         else:
           print("The matrix is not perfect.")
         print()  
    print("Finish")
main()