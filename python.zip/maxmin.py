# -*- coding: utf-8 -*-
"""
Created on Mon Nov 28 11:51:09 2022

@author: foaad
"""
def times_Apear(n,lst):
    c=0
    for x in lst:
        if x==n:
            c+=1
    return c        
def lst_pre(lst):
    max=lst[0]
    min=lst[0]
    mostRecent=lst[0]
    maxApear=1
    for x in lst:
        if times_Apear(x, lst)>=maxApear:
            maxApear=times_Apear(x,lst)
            if x>mostRecent:
                mostRecent=x
        if x>max:
            max=x
        elif x<min:
            min=x
    return max,min,mostRecent
a=[1,2,3,4,5,9,7]    
print("the max is",lst_pre(a)[0],"the min is",lst_pre(a)[1],"Most recent number",lst_pre(a)[2])    