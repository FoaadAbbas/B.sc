import random
def main():
    print("GUESS NUMBER (1-10) in 5 ATTEMPTS")
    Rand = random.randint(1, 10)
    flag = False
    count = 0
    x = 11
    while int(count) < 5 and x != Rand:
        count += 1
        x = int(input("Attempt #"+str(count)+"\nEnter your guess:"))
        #print("Attempt #"+str(count))
        #x = int(input("Enter your guess:"))
        if x > Rand : print("Too big")
        elif x < Rand : print("Too small")  
        else :
            flag =True
            print("Exactly!\nYou won the game.\nYou have guessed the number in "+str(count)+" attempts.\nFINE")
    if not flag : print("You have lost the game.The number was",Rand,"\nFINISH")    
main()    