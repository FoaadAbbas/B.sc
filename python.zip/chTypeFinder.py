# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 16:15:43 2022

@author: foaad
"""

ch=str(input("enter char"))
print("\n",ch)
if('a'<=ch<='z'):
    print("lowercase")
elif('A'<=ch<='Z'):
    print("uppercase")
elif('0'<=ch<='9'):
    print("number")    
else:
    print("neither")    
    