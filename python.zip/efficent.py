def is_off(n):
    l = [False]*n
    c = 2
    place = 1
    while c <= n:
        for i in range(1,n):
            if c%i == 0:
                l[i] = not l[i]
        c += 1        
    for x in l:
        if x == False:
            print("[%d]"%place)
        place += 1
is_off(100)        
        