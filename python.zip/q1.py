def main():
    number=int(input("Enter a positive integer (-1 for end): "))
    length = 1#length of sequence
    previous = 0 #the previous number
    max_length = 0# the biggest length
    max_value = number# the biggest number
    while number!=-1:#we get number from the user till we get -1
        previous = number #change previous to current x before getting the new x
        number=int(input("Enter a positive integer (-1 for end): "))
        if previous==number: #add 1 to the length untill you get number that does not equal the numbers in sequence
            length += 1
        else:#if the x cant be part of sequence
            if max_length < length:
                max_length = length#we serach for the max length of sequence
                max_value = previous
            elif max_length == length:
                if max_value < previous:#now we find that max value if we have sequences with the same length
                    max_value = previous
            length = 1 #if we get diffrent number we start to count again
    print("The length of the longest sequence of equal numbers is: ",max_length,"consist of the number",max_value)
main()