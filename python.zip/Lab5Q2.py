# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 13:55:01 2022

@author: foaad
"""

def main():
    a1=eval(input("Enter first element of Geometric Progression Series: "))
    q=eval(input("\nEnter the common Ratio : "))
    n=int(input("\nEnter integer n:"))
    print("\nGeometric Progression Series")
    for i in range(n):
        print(a1*(q**(i)),end=" ")#an=a1*(q**(n-1))
main()        