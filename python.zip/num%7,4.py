# -*- coding: utf-8 -*-
"""
Created on Mon Nov 14 10:56:24 2022

@author: foaad
"""
def main():
 min=int(input("please enter your min: "))
 max=int(input("pleasd enter your max: "))
 num=min
 while(num<=max and num>=min):
    if(num%7==0 or num%4==0):
        print(num,end=' ')
    num+=1
main()  
