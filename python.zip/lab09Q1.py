def printmat(mat):
    "func that prints the mat in readable way"
    for i in mat:
        print(f"{i}")
def is_valid_row(mat,row):
   rowSum = 0#sum of numbers in the row
   for i in mat[row]:#for every number in the row
        rowSum += i#add it to the sum
   return rowSum == row#return the value of this bolean equation(if they are equal its true)     

def is_slant(mat):
    for i in range(len(mat)):
        if mat[i][i] < 0: return False#numbers on slant are in [i][i]form,colum = row
    return True#if none of the numbers at the slant is     

def main():
    mat = [[31,-15,0,-12,-4],
           [1,1,-3,2,0],
           [12,-2,4,-23,11],
           [5,0,3,2,-7],
           [1,1,0,1,1]]
    mat2 = [[1,2,3,4,5],
            [6,7,8,9,0],
            [1,2,3,4,5],
            [6,7,8,9,0],
            [1,2,3,4,5]]
    flag = True#bolean varriable that sayes if the matrix is valid or not
    printmat(mat)#print the mat we are checking
    for row in range (len(mat)):
        if not(is_valid_row(mat,row)): flag = False#if we found row that isnt valid so false
    if not(is_slant(mat)): flag = False#if not all numbers on slant are positive so false
    print("the given matrix is valid") if flag else print("the given matrix is not valid")#if we didnt get false all the way print valid else print not valid
main()


    
        