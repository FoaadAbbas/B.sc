12# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 15:33:00 2022

@author: foaad
"""
def main():
 a=eval(input("enter a number "))
 print("\n""Number",'%8s'%"Square",'%8s'%"Cube")
 print(a,'%10d'%a**2,'%10d'%a**3)
 print((a+1),'%10d'%((a+1)**2),'%10d'%((a+1)**3))
 print((a+2),'%10d'%((a+2)**2),'%10d'%((a+2)**3))
 print((a+3),'%10d'%((a+3)**2),'%10d'%((a+3)**3))
 print((a+4),'%10d'%((a+4)**2),'%10d'%((a+4)**3))
main()    