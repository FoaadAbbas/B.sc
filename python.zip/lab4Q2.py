# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 13:27:17 2022

@author: foaad
"""

def main():
    x=eval(input("Enter a positive 4-digits number: "))
    if(x<0):#if number is negetive
        print(x,"is a negative number. Bye bye.")
    elif x<1000 or x>9999:#if not the right amount of digits
        print(x,"is not a 4-digits number. Bye bye.")
    else:
     u=x%10 #calculat units
     t=(x%100)//10 #calculat tens
     h=(x%1000)//100#calculat hundreds
     th=(x%10000)//1000#calculat thousends
     if(u==t) and t==h and h==th:#if digits equals
         print("All digits are the same")
     else:
        if (u>t and t>h and h>th) and (t-u==h-t) and(h-t==th-h):#if increasing
            print("Increasing aritmetic sequence (from left to right) ")
        elif (u>=t and t>=h and h>=th):#no constant d but increasing
            print("Ascending sequence (from left to right)")
        elif (th>h and h>t and t>u) and (th-h==h-t) and (h-t==t-u) :
         print("Decreasing aritmetic sequence (from left to right)")
        elif (th>=h and h>=t and t>=u):# no constant d but decreasing
            print("Desceding sequence (from left to right)")
        else:#non of the options occured
         print("Non decreasing and non increasing")
main()        
        