# -*- coding: utf-8 -*-
"""
Created on Mon Nov 28 15:41:09 2022

@author: foaad
"""

def all_Same(lst):
    n=lst[0]
    for x in lst:
        if x!=n:
            return False
    return True  

def is_L1_in_L2(L1,L2):
    for x in L1:
        if(L2.count(x))==0:
            return False
    return True   

def is_L1_Diff_L2(L1,L2):
    for x in L1:
        if(L2.count(x))!=0:
                return False
    return True        

def Intersect(L1,L2):
    L3=[]
    for x in L1 :
        if(L2.count(x))>0 and (x  not in L3):
             L3.append(x)
    return L3    

def notInCommon(L1,L2):
    L3=[]
    for x in L1+L2:
        if x in L2 and x not in L1+L3:
            L3.append(x)
        if x in L1 and x not in L2+L3:
            L3.append(x)
    return L3        
a=[1,2,3]
b=[4,5,6,7,8,9]
print(notInCommon(a,b))