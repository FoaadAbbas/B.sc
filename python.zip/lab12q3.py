def TrueB(b):#func to check that b consits from 0 and 1 only
    for x in b:#for every char
        if x != '0' and x != '1' : return False#if not 0 or 1 false
    return True#if all arr 0 and 1
    
def ZerosOnes(a,b):#func that do part a of our ece
    if b == 0 : return 0#stopping condtion
    return a%10 * b%10 + 10 * ZerosOnes(a//10, b//10) #current + next until b is 0 we do * 10    
    #because In every recursion call we move to the next digit
def main():
    a = int(input("Enter a: "))#take a 
    b = int(input("Enter b: "))#take b
    print(ZerosOnes(a, b)) if len(str(b)) <= len(str(a)) and TrueB(str(b)) else print("Ops!")  
    #print the answer if b is shorter than a and b is only zeros or ones else print ops!
    #i check if b has only zeros and ones because either the func is useless
main()    