def areAlmostEqual(s1,s2): #The function areAlmostEqual that takes two strings s1 and s2 as input and checks if they are almost equal.
    if (s1 == "") or (s2 == "") : return (s1 == s2)#speacil case , at least one of the strings are empty
    if (len(s1) == 1) or (len(s2) == 1) : return ((s1*len(s2) == s2) or (s2*len(s1) == s1))
    if (s1[0] != s2[0]) : return False #if they do not have the same start they cant be almost equal
    if (s1[0] == s1[1]) : return areAlmostEqual(s1[1:], s2)#delete duplicates from s1
    if (s2[0] == s2[1]) : return areAlmostEqual(s1, s2[1:])#delete duplicates from s2
    return areAlmostEqual(s1[1:], s2[1:])#check the rest of the strings
def main():
    strings = [
        ["happpy   spriingggg", "happy spring"],
        ["Hapsy ring", "Happy Spring"],
        ["Happy Sumerrrr ", "HHHapy     Summer  "],
        ["Happy Sumerrrr ", "HHHapy     Summer"],
    ]

    for twoStrings in strings:#for every two strings in our list,print if they are almost equal or not
        if (areAlmostEqual(twoStrings[0], twoStrings[1])) : print(twoStrings[0] , twoStrings[1] ,"are almost equal")#if true
        else : print(twoStrings[0] , twoStrings[1] ,"are not almost equal")#if false

main()