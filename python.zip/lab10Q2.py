def goodPrint(mat):#func to print matrix in good looking way
    for i in mat:#for every roww
        for x in i:#for every number in row
            print(""*2,x,end=" ")#i assume that only is_extreme have to be o(n)
        print()
        
def is_extreme(matrix):
    if len(matrix) <= 1: return True #i assume that empty matrix is matrix,and that its extreme
    elif len(matrix[0]) != len(matrix): return False#if matrix is not n*n
    else : 
        sideMax = 0 #biggest number in second
        for i in range(len(matrix)):
            sideMax = matrix[i][len(matrix)-i-1] if matrix[i][len(matrix)-i-1] > sideMax else sideMax#save the biggest
        for i in range(len(matrix[0])):
            if matrix [i][i] < sideMax : return False#its not extreme if that happens
    return True#if all numbers are ok

def main():
    mat1 = [[1,2,3,4,5],
            [6,7,8,9,0],
            [1,2,3,4,5],
            [6,7,8,9,0],
            [1,2,3,4,5]]

    mat2 = [[5,2,3,4,2],
            [6,7,8,3,0],
            [1,2,4,4,5],
            [1,2,3,4,5]]

    mat3 = [[5,2,3,4,2],
            [6,7,8,3,0],
            [1,2,4,4,5],
            [6,0,8,9,0],
            [1,2,3,4,5]]       
    print(" "*3,"mat 1")
    goodPrint(mat1)
    print("mat 1 is extreme?",'yes' if is_extreme(mat1) else "no")
    print("\n"+' '*3,"mat 2")
    goodPrint(mat2)
    print("mat 2 is extreme?",'yes' if is_extreme(mat2) else 'no')
    print("\n"+' '*3,"mat 3")
    goodPrint(mat3)
    print("mat 3 is extreme?",'yes' if is_extreme(mat3) else 'no')
main()    
    