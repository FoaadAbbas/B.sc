def main():
    c=int(input("Enter number of children: "))
    s=int(input("\nEnter your monthly salary: "))
    mc=input("\nMillitary or civil service?\nFor yes enter y,otherwise -any other characther: ")
    if mc=='y' and (s>15000):#we check if option 1 or 2 existing but not 3
        if(s<17500):#not option 3
            print("The mortgage is approved with monthly payment of ",int(s*0.25),".")
    elif c>=5 and 17500>s and s>14000:#check option 2 but not 3
         print("The mortgage is approved with monthly payment of ",int(s*0.25),".")       
    elif s>17500:#optin 3
         print("The mortgage is approved with monthly payment of ",int(s*0.35),".")
    else:# if not option 1 or option 2 or option 3
          print("The mortgage is not approved.")    
main()